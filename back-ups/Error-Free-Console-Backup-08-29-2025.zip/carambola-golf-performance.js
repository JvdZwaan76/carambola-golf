/**
 * Carambola Golf Club - SIMPLIFIED Performance Worker
 * Fixes MIME type errors and console warnings without HTML manipulation
 * Version 2.3.0 - Safe deployment
 */

const CONFIG = {
  CACHE_TTL: {
    html: 3600,
    css: 86400,
    js: 86400,
    images: 604800,
    fonts: 2592000,
    static: 86400
  },
  
  // Minimal security headers to avoid conflicts
  SECURITY_HEADERS: {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  }
};

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request, event));
});

async function handleRequest(request, event) {
  const url = new URL(request.url);
  const cache = caches.default;
  const cacheKey = new Request(url.toString(), request);
  
  try {
    // Handle favicon generation
    if (url.pathname.includes('favicon') || 
        url.pathname === '/android-chrome-192x192.png') {
      return handleFavicon();
    }
    
    // Check cache first
    if (request.method === 'GET') {
      const cachedResponse = await cache.match(cacheKey);
      if (cachedResponse) {
        return addHeaders(cachedResponse, true);
      }
    }
    
    // Fetch the resource
    const response = await fetch(request, {
      cf: {
        cacheEverything: true,
        cacheTtl: getCacheTTL(url)
      }
    });
    
    // Don't modify HTML - let your optimized head work
    const modifiedResponse = addHeaders(response.clone(), false);
    
    // Cache the response
    if (response.ok && request.method === 'GET') {
      event.waitUntil(cache.put(cacheKey, response.clone()));
    }
    
    return modifiedResponse;
    
  } catch (error) {
    console.error('Worker error:', error);
    return fetch(request);
  }
}

function addHeaders(response, fromCache) {
  const newResponse = new Response(response.body, response);
  const url = new URL(response.url);
  
  // Add minimal security headers
  Object.entries(CONFIG.SECURITY_HEADERS).forEach(([key, value]) => {
    newResponse.headers.set(key, value);
  });
  
  // Add performance headers
  const ttl = getCacheTTL(url);
  newResponse.headers.set('Cache-Control', getCacheControl(url, ttl));
  newResponse.headers.set('X-Cache', fromCache ? 'HIT' : 'MISS');
  
  // Add CORS headers for assets to fix crossorigin issues
  if (isAssetRequest(url)) {
    newResponse.headers.set('Access-Control-Allow-Origin', '*');
    newResponse.headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    newResponse.headers.set('Cross-Origin-Resource-Policy', 'cross-origin');
  }
  
  // Ensure correct content types
  const pathname = url.pathname.toLowerCase();
  if (pathname.endsWith('.webp')) {
    newResponse.headers.set('Content-Type', 'image/webp');
  } else if (pathname.endsWith('.css')) {
    newResponse.headers.set('Content-Type', 'text/css; charset=utf-8');
  } else if (pathname.endsWith('.js')) {
    newResponse.headers.set('Content-Type', 'application/javascript; charset=utf-8');
  }
  
  return newResponse;
}

function handleFavicon() {
  const faviconSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
    <circle cx="16" cy="16" r="14" fill="#d4af37"/>
    <text x="16" y="22" text-anchor="middle" fill="#1e3a5f" font-size="18" font-family="serif" font-weight="bold">C</text>
  </svg>`;
  
  return new Response(faviconSVG, {
    headers: {
      'Content-Type': 'image/svg+xml',
      'Cache-Control': 'public, max-age=86400',
      'Access-Control-Allow-Origin': '*'
    }
  });
}

function getCacheTTL(url) {
  const pathname = url.pathname.toLowerCase();
  const extension = pathname.split('.').pop() || '';
  
  const assetTypes = {
    'css': CONFIG.CACHE_TTL.css,
    'js': CONFIG.CACHE_TTL.js,
    'webp': CONFIG.CACHE_TTL.images,
    'png': CONFIG.CACHE_TTL.images,
    'jpg': CONFIG.CACHE_TTL.images,
    'jpeg': CONFIG.CACHE_TTL.images,
    'svg': CONFIG.CACHE_TTL.images,
    'ico': CONFIG.CACHE_TTL.images,
    'woff': CONFIG.CACHE_TTL.fonts,
    'woff2': CONFIG.CACHE_TTL.fonts
  };
  
  if (pathname === '/' || pathname.endsWith('.html')) {
    return CONFIG.CACHE_TTL.html;
  }
  
  return assetTypes[extension] || CONFIG.CACHE_TTL.static;
}

function getCacheControl(url, ttl) {
  const pathname = url.pathname.toLowerCase();
  
  if (pathname.includes('/images/') || pathname.includes('/fonts/')) {
    return `public, max-age=${ttl}, s-maxage=${ttl}, immutable`;
  }
  
  return `public, max-age=${ttl}, s-maxage=${Math.floor(ttl / 2)}`;
}

function isAssetRequest(url) {
  const pathname = url.pathname.toLowerCase();
  const assetExtensions = ['css', 'js', 'png', 'jpg', 'jpeg', 'webp', 'svg', 'woff', 'woff2', 'ico'];
  const extension = pathname.split('.').pop() || '';
  return assetExtensions.includes(extension);
}